<button type="submit" class="bg-[#66A5AD] hover:bg-[#458998] text-black font-bold py-2 px-4 rounded">
    {{ $slot }}
</button>
