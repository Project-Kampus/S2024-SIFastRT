<img src="{{ asset('images/SIFastRT.png') }}" alt="Deskripsi Gambar" class="w-36 h-auto">
