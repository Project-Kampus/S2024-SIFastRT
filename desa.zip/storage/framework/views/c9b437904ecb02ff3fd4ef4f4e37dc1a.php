<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Detail Laporan')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-7">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Container untuk Informasi Laporan -->
                <div class="bg-white overflow-hidden shadow-md rounded-lg p-6">
                    <h3 class="font-semibold text-lg border-b pb-2 mb-4">Informasi Laporan</h3>
                    <p class="mb-2"><strong>Nama Pelapor:</strong> <?php echo e($laporan->nama_pelapor); ?></p>
                    <p class="mb-2"><strong>Tanggal Laporan:</strong> <?php echo e($laporan->created_at->format('d-m-Y H:i')); ?></p>
                    <p class="mb-2"><strong>Deskripsi:</strong> <?php echo e($laporan->deskripsi); ?></p>
                    <p class="font-semibold text-green-600"><strong>Status:</strong> <?php echo e($laporan->status); ?></p>
                </div>

                <!-- Container untuk Tindak Lanjut -->
                <div class="bg-white overflow-hidden shadow-md rounded-lg p-6">
                    <h3 class="font-semibold text-lg border-b pb-2 mb-4">Tindak Lanjut</h3>
                    <form action="<?php echo e(route('admin.laporan.update', $laporan->id)); ?>" method="POST" class="mb-4">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <label for="status" class="block mb-2 font-medium">Pilih Status</label>
                        <select name="status" id="status" class="border-gray-300 rounded-md shadow-sm bg-white text-gray-900 mb-4 w-full">
                            <option value="baru" <?php echo e($laporan->status === 'baru' ? 'selected' : ''); ?>>Baru</option>
                            <option value="diproses" <?php echo e($laporan->status === 'diproses' ? 'selected' : ''); ?>>Diproses</option>
                            <option value="selesai" <?php echo e($laporan->status === 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                        </select>

                        <label for="catatan" class="block mb-2 font-medium">Catatan</label>
                        <textarea name="catatan" id="catatan" placeholder="Masukkan catatan..." class="border-gray-300 rounded-md shadow-sm bg-white text-gray-900 mb-4 w-full" rows="3"><?php echo e(old('catatan', $laporan->catatan)); ?></textarea>
                        
                        <div class="flex justify-center">
                            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit','class' => 'w-full']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'w-full']); ?>
                                Simpan
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\project laravel\rara_p\resources\views/admin/laporan/show.blade.php ENDPATH**/ ?>