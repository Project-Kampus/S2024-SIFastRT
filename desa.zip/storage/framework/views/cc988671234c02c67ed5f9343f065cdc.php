<?php echo e($slot); ?>

<?php /**PATH C:\project laravel\Desa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>