<button type="submit" class="bg-[#66A5AD] hover:bg-[#458998] text-black font-bold py-2 px-4 rounded">
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\project laravel\rara_p\resources\views/components/button.blade.php ENDPATH**/ ?>