<?php echo e($slot); ?>

<?php /**PATH C:\project laravel\rara_p\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>