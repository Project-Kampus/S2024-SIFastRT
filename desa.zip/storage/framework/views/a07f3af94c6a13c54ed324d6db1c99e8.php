<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Peminjaman')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-7">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="bg-[#C4DFE6] text-center p-4 mb-4">
                    <h1 class="text-2xl font-bold">Detail Fasilitas</h1>
                </div>
                <div class="p-6 text-gray-900">
                    <?php if(session('status')): ?>
                        <div class="bg-green-500 text-white p-4 mb-4 rounded">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('admin.peminjaman.update', $peminjaman->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-4 flex items-center">
                            <label for="nama" class="w-1/3">Nama:</label>
                            <input type="text" name="nama" id="nama" value="<?php echo e($peminjaman->nama); ?>" class="border rounded-md w-2/3 bg-[#C4DFE6] ml-4" required>
                        </div>

                        <div class="mb-4 flex items-center">
                            <label for="fasilitas" class="w-1/3">Fasilitas:</label>
                            <select name="fasilitas" id="fasilitas" class="border rounded-md w-2/3 bg-[#C4DFE6] ml-4" required>
                                <option value="tenda" <?php echo e($peminjaman->fasilitas === 'tenda' ? 'selected' : ''); ?>>Tenda</option>
                                <option value="sound system" <?php echo e($peminjaman->fasilitas === 'sound system' ? 'selected' : ''); ?>>Sound System</option>
                                <option value="kursi" <?php echo e($peminjaman->fasilitas === 'kursi' ? 'selected' : ''); ?>>Kursi</option>
                            </select>
                        </div>

                        <div class="mb-4 flex items-center">
                            <label for="tanggal_peminjaman" class="w-1/3">Tanggal Peminjaman:</label>
                            <input type="date" name="tanggal_peminjaman" id="tanggal_peminjaman" value="<?php echo e($peminjaman->tanggal_peminjaman); ?>" class="border rounded-md w-2/3 bg-[#C4DFE6] ml-4" required>
                        </div>

                        <div class="mb-4 flex items-center">
                            <label for="tanggal_pengembalian" class="w-1/3">Tanggal Pengembalian:</label>
                            <input type="date" name="tanggal_pengembalian" id="tanggal_pengembalian" value="<?php echo e($peminjaman->tanggal_pengembalian); ?>" class="border rounded-md w-2/3 bg-[#C4DFE6] ml-4" required>
                        </div>

                        <div class="mb-4 flex items-center">
                            <label for="status" class="w-1/3">Status:</label>
                            <select name="status" id="status" class="border rounded-md w-2/3 bg-[#C4DFE6] ml-4" required>
                                <option value="sedang menunggu" <?php echo e($peminjaman->status === 'sedang menunggu' ? 'selected' : ''); ?>>Sedang Menunggu</option>
                                <option value="dipinjam" <?php echo e($peminjaman->status === 'dipinjam' ? 'selected' : ''); ?>>Dipinjam</option>
                            </select>
                        </div>
                        <div class="flex justify-center">
                            <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>Simpan <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\project laravel\rara_p\resources\views/admin/peminjaman/edit.blade.php ENDPATH**/ ?>